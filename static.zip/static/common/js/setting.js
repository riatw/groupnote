// app setting
var SETTING = {};
SETTING.CMSURL = "https://sky-inet.com/mt_api/mt-data-api.fcgi/v3";
SETTING.CMSURL2 = "https://sky-inet.com/mt_api/mt-data-api.fcgi";
SETTING.BLOGID = 1;
