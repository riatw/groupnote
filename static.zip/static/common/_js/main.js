var $ = require('jquery');
var jQuery = require('jquery');
